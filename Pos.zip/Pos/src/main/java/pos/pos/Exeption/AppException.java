package pos.pos.Exeption;

public class AppException extends RuntimeException {
  public AppException(String message) { super(message); }
}

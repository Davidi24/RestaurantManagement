package pos.pos.Entity.Menu;

public enum OptionGroupType {
    SINGLE,
    MULTI
}

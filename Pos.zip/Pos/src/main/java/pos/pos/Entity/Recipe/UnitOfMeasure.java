package pos.pos.Entity.Recipe;

public enum UnitOfMeasure { G, KG, ML, L, PCS }
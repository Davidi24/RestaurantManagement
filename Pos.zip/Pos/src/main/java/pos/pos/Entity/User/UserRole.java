package pos.pos.Entity.User;

public enum UserRole {
  USER,
  ADMIN,
  SUPERADMIN,
  WAITER,
  KITCHEN,
  MANAGER
}

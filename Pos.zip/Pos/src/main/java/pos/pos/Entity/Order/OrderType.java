package pos.pos.Entity.Order;

public enum OrderType {
    DINE_IN
}

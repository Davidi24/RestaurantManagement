package pos.pos.Service.Interfecaes.Menu;

import pos.pos.DTO.Menu.MenuSectionDTO.MenuSectionCreateRequest;
import pos.pos.DTO.Menu.MenuSectionDTO.MenuSectionResponse;
import pos.pos.DTO.Menu.MenuSectionDTO.MenuSectionUpdateRequest;

import java.util.List;

public interface MenuSectionService {

    List<MenuSectionResponse> listSections(Long menuId);

    MenuSectionResponse createSection(Long menuId, MenuSectionCreateRequest req);

    MenuSectionResponse updateSection(Long menuId, Long sectionId, MenuSectionUpdateRequest req);

    void deleteSection(Long menuId, Long sectionId);

    MenuSectionResponse moveSection(Long menuId, Long sectionId, int newSortOrder);

    MenuSectionResponse getSection(Long menuId, Long sectionId);
}
